Ferienhaus Marianne 1.0.2 – 37 selected photos + approved app icon + Wolfgangsee skyline.
The photos were provided in chat by the project owner. Confirm that you have reuse rights before posting them in a public GitHub repository.
Upload the entire ZIP as uploads/ferienhaus-marianne-1.0.2-assets.zip to your GitHub repository; the workflow installed with version 1.0.2 will unpack and optimize the website.
Dorf der Tiere remains hidden.
